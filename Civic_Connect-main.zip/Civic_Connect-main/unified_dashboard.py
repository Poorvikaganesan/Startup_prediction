import streamlit as st
import sys
import os

# Add new modules to path
sys.path.append('new_ml_civic_monitoring')

# Import new ML modules
from new_ml_civic_monitoring.complaint_analysis import run_complaint_analysis
from new_ml_civic_monitoring.fault_prediction import run_fault_prediction
from new_ml_civic_monitoring.risk_mapping import run_risk_mapping
from new_ml_civic_monitoring.business_insights import run_business_insights

def run_yolo_integration():
    """Run the actual YOLO image prediction with proper integration"""
    try:
        # Import and run the YOLO prediction function
        from existing_yolo_modules.yolo_integration import run_yolo_prediction
        run_yolo_prediction()
    except ImportError as e:
        st.error(f"YOLO module import error: {e}")
        # Fallback to basic version
        st.header("📸 Image Issue Detection")
        st.warning("YOLO integration not available. Using basic version.")
        
        uploaded_file = st.file_uploader("Upload image for analysis", type=['jpg', 'jpeg', 'png'])
        if uploaded_file:
            st.image(uploaded_file, caption="Uploaded Image", use_column_width=True)
            st.info("YOLO prediction would run here with your existing model")
    except Exception as e:
        st.error(f"Error running YOLO: {e}")
        st.info("Make sure your YOLO model file (best.pt) is in the existing_yolo_modules folder")

def main():
    st.set_page_config(
        page_title="Civic AI Monitoring System",
        page_icon="🏙️",
        layout="wide"
    )
    
    st.title("🏙️ Smart ML-Driven Civic Issue & Resource Monitoring System")
    st.markdown("""
    **Clean & Green Technology – Software Solution**
    
    *Unified platform combining image-based detection with data-driven ML analytics*
    """)
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    app_mode = st.sidebar.selectbox(
        "Choose Module",
        [
            "🏠 Dashboard Overview",
            "📸 Image Issue Detection (Existing YOLO)",
            "📝 Complaint Analysis (New ML)",
            "🔮 Fault Prediction (New ML)", 
            "🗺️ Risk Mapping (New ML)",
            "📊 Business Insights (New ML)"
        ]
    )
    
    # Main content routing
    if app_mode == "🏠 Dashboard Overview":
        show_dashboard_overview()
    if app_mode == "📸 Image Issue Detection (Existing YOLO)":
        run_yolo_integration()
    elif app_mode == "📝 Complaint Analysis (New ML)":
        try:
            from data_management.data_loader import run_complaint_analysis_real
            run_complaint_analysis_real()
        except ImportError:
            # Fallback to basic complaint analysis
            run_complaint_analysis()
    elif app_mode == "🗺️ Risk Mapping (New ML)":
        run_risk_mapping()
    elif app_mode == "📊 Business Insights (New ML)":
        run_business_insights()

def show_dashboard_overview():
    """Show main dashboard with all module overview"""
    st.header("📊 System Overview")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Existing Modules", "1", "YOLO Image Classification")
    with col2:
        st.metric("New ML Modules", "4", "Complaint, Fault, Risk, Insights")
    with col3:
        st.metric("Integration", "Complete", "Unified Dashboard")
    
    st.markdown("""
    
    ### 🚀 Getting Started
    
    1. **Explore Existing Features**: Use the 'Image Issue Detection' for your current YOLO system
    2. **Try New ML Modules**: Test complaint analysis and fault prediction with sample data
    3. **Upload Real Data**: Use CSV uploads for your actual civic data
    4. **Generate Insights**: Get automated business intelligence from the analytics modules
    """)

if __name__ == "__main__":
    main()
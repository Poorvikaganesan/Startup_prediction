import pandas as pd
import numpy as np
import streamlit as st
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

class FaultPredictor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.anomaly_detector = IsolationForest(contamination=0.1, random_state=42)
        self.is_trained = False
    
    def generate_sample_utility_data(self):
        """Generate sample utility data for demonstration"""
        dates = pd.date_range('2024-01-01', '2024-06-01', freq='D')
        
        data = []
        for i, date in enumerate(dates):
            # Simulate seasonal patterns
            seasonal = 10 * np.sin(2 * np.pi * i / 365)
            trend = 0.05 * i
            noise = np.random.normal(0, 2)
            
            water_usage = 100 + seasonal + trend + noise
            pressure_level = 50 + 5 * np.sin(2 * np.pi * i / 30) + np.random.normal(0, 3)
            energy_consumption = 200 + 20 * np.sin(2 * np.pi * i / 7) + np.random.normal(0, 5)
            
            # Introduce some anomalies
            if i in [45, 46, 47, 120, 121]:  # Simulate fault periods
                water_usage *= 1.5
                pressure_level *= 0.3
            
            data.append({
                'timestamp': date,
                'water_usage': max(water_usage, 0),
                'pressure_level': max(pressure_level, 0),
                'energy_consumption': max(energy_consumption, 0),
                'location': f"Zone {i % 5 + 1}"
            })
        
        return pd.DataFrame(data)
    
    def create_features(self, df):
        """Feature engineering for time-series data"""
        df = df.copy()
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        # Time-based features
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        df['month'] = df['timestamp'].dt.month
        df['day_of_year'] = df['timestamp'].dt.dayofyear
        
        # Rolling statistics
        df['usage_rolling_mean_7'] = df['water_usage'].rolling(window=7).mean()
        df['usage_rolling_std_7'] = df['water_usage'].rolling(window=7).std()
        df['pressure_rolling_mean_7'] = df['pressure_level'].rolling(window=7).mean()
        
        # Lag features
        df['usage_lag_1'] = df['water_usage'].shift(1)
        df['usage_lag_7'] = df['water_usage'].shift(7)
        
        return df.dropna()
    
    def perform_eda(self, df):
        """Exploratory Data Analysis for utility data"""
        st.subheader("📈 Utility Data Analysis")
        
        # Time series plots
        fig1 = px.line(df, x='timestamp', y='water_usage', 
                      title='Water Usage Over Time',
                      color_discrete_sequence=['#1f77b4'])
        st.plotly_chart(fig1, use_container_width=True)
        
        col1, col2 = st.columns(2)
        with col1:
            fig2 = px.histogram(df, x='water_usage', 
                              title='Water Usage Distribution',
                              color_discrete_sequence=['#ff7f0e'])
            st.plotly_chart(fig2, use_container_width=True)
        
        with col2:
            fig3 = px.box(df, y='water_usage', 
                         title='Water Usage Statistics')
            st.plotly_chart(fig3, use_container_width=True)
        
        # Correlation heatmap
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        corr_matrix = df[numeric_cols].corr()
        
        fig4 = px.imshow(corr_matrix, 
                        title='Feature Correlation Heatmap',
                        color_continuous_scale='RdBu_r',
                        aspect="auto")
        st.plotly_chart(fig4, use_container_width=True)
        
        return df
    
    def detect_anomalies(self, df):
        """Detect anomalies in utility data"""
        st.subheader("🚨 Anomaly Detection")
        
        features = ['water_usage', 'pressure_level', 'energy_consumption']
        X = df[features].fillna(method='ffill')
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Detect anomalies
        anomalies = self.anomaly_detector.fit_predict(X_scaled)
        df['anomaly_score'] = self.anomaly_detector.decision_function(X_scaled)
        df['is_anomaly'] = anomalies == -1
        
        # Visualize anomalies
        fig = px.scatter(df, x='timestamp', y='water_usage',
                        color='is_anomaly', 
                        title='Anomaly Detection in Water Usage',
                        color_discrete_sequence=['blue', 'red'],
                        symbol='is_anomaly')
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Anomaly statistics
        anomaly_count = df['is_anomaly'].sum()
        st.metric("🚨 Anomalies Detected", anomaly_count)
        
        if anomaly_count > 0:
            st.write("**Anomalous Periods:**")
            anomaly_periods = df[df['is_anomaly']][['timestamp', 'water_usage', 'anomaly_score']]
            st.dataframe(anomaly_periods, use_container_width=True)
        
        return df
    
    def train_prediction_model(self, df):
        """Train fault prediction model"""
        st.subheader("🔮 Fault Prediction Model")
        
        # Create features
        df_engineered = self.create_features(df)
        
        # Prepare features and target
        feature_cols = ['hour', 'day_of_week', 'month', 'day_of_year',
                       'usage_rolling_mean_7', 'usage_rolling_std_7', 
                       'pressure_rolling_mean_7', 'usage_lag_1', 'usage_lag_7']
        
        X = df_engineered[feature_cols]
        y = df_engineered['water_usage']
        
        # Split data (temporal split)
        split_idx = int(0.8 * len(X))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Train model
        self.rf_model.fit(X_train, y_train)
        
        # Predictions
        y_pred = self.rf_model.predict(X_test)
        
        # Calculate metrics
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        
        # Display results
        col1, col2 = st.columns(2)
        with col1:
            st.metric("MAE (Mean Absolute Error)", f"{mae:.2f}")
        with col2:
            st.metric("RMSE (Root Mean Square Error)", f"{rmse:.2f}")
        
        # Plot predictions vs actual
        results_df = pd.DataFrame({
            'Actual': y_test.values,
            'Predicted': y_pred,
            'Timestamp': df_engineered['timestamp'].iloc[split_idx:split_idx + len(y_test)]
        })
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=results_df['Timestamp'], y=results_df['Actual'],
                               name='Actual', line=dict(color='blue')))
        fig.add_trace(go.Scatter(x=results_df['Timestamp'], y=results_df['Predicted'],
                               name='Predicted', line=dict(color='red', dash='dash')))
        fig.update_layout(title='Actual vs Predicted Water Usage',
                         xaxis_title='Date', yaxis_title='Water Usage')
        
        st.plotly_chart(fig, use_container_width=True)
        
        self.is_trained = True
        return mae, rmse

def run_fault_prediction():
    """Streamlit interface for fault prediction"""
    st.header("🔮 Smart Fault Prediction System")
    
    predictor = FaultPredictor()
    
    # Load sample data
    st.subheader("📁 Utility Data Overview")
    df = predictor.generate_sample_utility_data()
    st.success("✅ Sample utility data loaded successfully!")
    
    st.dataframe(df.head(10), use_container_width=True)
    
    # EDA
    df = predictor.perform_eda(df)
    
    # Anomaly detection
    df = predictor.detect_anomalies(df)
    
    # Model training
    if st.button("🚀 Train Prediction Model"):
        with st.spinner("Training prediction model..."):
            mae, rmse = predictor.train_prediction_model(df)
            st.success(f"Model trained! MAE: {mae:.2f}, RMSE: {rmse:.2f}")
    
    # Future prediction
    st.subheader("📅 Predict Future Usage")
    days_ahead = st.slider("Days to predict ahead:", 1, 30, 7)
    
    if st.button("Generate Forecast") and predictor.is_trained:
        st.info("Future prediction feature would be implemented with full historical data")
        # Implementation for future predictions would go here